﻿Imports System.Data.Odbc

Public Class form13
    Dim Conn As OdbcConnection
    Dim cmd As OdbcCommand
    Dim Da As OdbcDataAdapter
    Dim rd As OdbcDataReader
    Dim Ds As DataSet
    Dim MyDB As String
    Sub koneksi()
        MyDB = "Driver={Mysql ODBC 3.51 Driver};Database=dbnasabah;server=localhost;uid=root"
        Conn = New OdbcConnection(MyDB)
        If Conn.State = ConnectionState.Closed Then
            Conn.Open()
        End If
    End Sub
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        Da = New OdbcDataAdapter("Select * from tbriwayat where Nama like '%" & TextBox1.Text & "%'", Conn)
        Ds = New DataSet
        Da.Fill(Ds)
        DataGridView1.DataSource = Ds.Tables(0)
        DataGridView1.ReadOnly = True
    End Sub

    Private Sub form13_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call koneksi()
        Da = New OdbcDataAdapter("select * from tbriwayat", Conn)
        Ds = New DataSet
        Ds.Clear()
        Da.Fill(Ds, "tbriwayat")
        DataGridView1.DataSource = (Ds.Tables("tbriwayat"))
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If MessageBox.Show("Yakin Ingin Kembali?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
            Me.Hide()
            form11.Show()
        End If

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class