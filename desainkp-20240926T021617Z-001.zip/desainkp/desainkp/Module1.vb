﻿Imports System.Data.Odbc
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar

Module module1
    Public Class Form3
        Dim Conn As OdbcConnection
        Dim cmd As OdbcCommand
        Dim Da As OdbcDataAdapter
        Dim rd As OdbcDataReader
        Dim Ds As DataSet
        Dim MyDB As String
        Sub koneksi()
            MyDB = "Driver={Mysql ODBC 3.51 Driver};Database=dbnasabah;server=localhost;uid=root"
            Conn = New OdbcConnection(MyDB)
            If Conn.State = ConnectionState.Closed Then
                Conn.Open()
            End If
        End Sub

    End Class
End Module
