﻿Partial Class DataSet1
    Partial Public Class tbnasabahDataTable
        Private Sub tbnasabahDataTable_tbnasabahRowChanging(sender As Object, e As tbnasabahRowChangeEvent) Handles Me.tbnasabahRowChanging

        End Sub

    End Class
End Class
