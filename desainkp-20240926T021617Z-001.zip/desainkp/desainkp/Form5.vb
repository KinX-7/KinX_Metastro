﻿Imports System.Data.Odbc
Imports System.Runtime.Remoting.Activation
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports Microsoft.Win32.SafeHandles

Public Class Form5
    Dim Conn As OdbcConnection
    Dim cmd As OdbcCommand
    Dim Da As OdbcDataAdapter
    Dim rd As OdbcDataReader
    Dim Ds As DataSet
    Dim MyDB As String
    Sub koneksi()
        MyDB = "Driver={Mysql ODBC 3.51 Driver};Database=dbnasabah;server=localhost;uid=root"
        Conn = New OdbcConnection(MyDB)
        If Conn.State = ConnectionState.Closed Then
            Conn.Open()
        End If
    End Sub
    Sub kondisiawal()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = "dd/MM/yyyy"
        TextBox7.Text = ""
        ComboBox1.Text = ""

    End Sub

    Sub carikode()
        cmd = New OdbcCommand("select * from tbdata where ID='" & TextBox1.Text & "'", Conn)
        rd = cmd.ExecuteReader
        rd.Read()
    End Sub
    Sub ketemu()
        On Error Resume Next
        TextBox1.Text = rd(0) '=ID
        TextBox2.Text = rd(1) '=Nama
        TextBox3.Text = rd(5) '=Saldo_Akhir
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If MessageBox.Show("Yakin Ingin Kembali?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
            Me.Hide()
            Form2.Show()
        End If
    End Sub
    Sub tampilgrid()
        Da = New OdbcDataAdapter("select * from tbdata", Conn)
        Ds = New DataSet
        Da.Fill(Ds)
        DataGridView1.DataSource = Ds.Tables(0)
        DataGridView1.ReadOnly = True
        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnMode.Fill

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        Me.Hide()
        Form7.Show()
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call koneksi()
        Da = New OdbcDataAdapter("select * from tbdata", Conn)
        Ds = New DataSet
        Ds.Clear()
        Da.Fill(Ds, "tbdata")
        DataGridView1.DataSource = (Ds.Tables("tbdata"))

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If TextBox6.Text = "" Or TextBox1.Text = "" Or TextBox2.Text = "" Or ComboBox1.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Then
            MsgBox("Data Belum Lengkap..!", vbInformation, "GAGAL!")
        Else
            Call koneksi()
            Dim SIMPAN As String = "Insert into tbriwayat values('" & TextBox6.Text & "','" & TextBox7.Text & "','" & TextBox1.Text & "','" & TextBox2.Text & "','" & ComboBox1.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "')"
            cmd = New OdbcCommand(SIMPAN, Conn)
            cmd.ExecuteNonQuery()
            MsgBox("Data Berhasil Disimpan...!")
            Call kondisiawal()
            Call tampilgrid()
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If ComboBox1.Text = "Tabungan" Then
            TextBox5.Text = Val(TextBox3.Text + Val(TextBox4.Text))
        ElseIf ComboBox1.Text = "Penarikan" Then
            TextBox5.Text = Val(TextBox3.Text - Val(TextBox4.Text))
            If TextBox3.Text < TextBox4.Text Then
                TextBox5.Text = ""
                MsgBox("Maaf, Saldo Kurang...!", vbInformation, "Gagal!")
            End If
        End If
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = Chr(13) Then
            Call koneksi()
            cmd = New OdbcCommand("Select * from tbriwayat where ID ='" & TextBox1.Text & "'", Conn)
            rd = cmd.ExecuteReader
            rd.Read()
            If rd.HasRows Then
                TextBox2.Text = rd.Item("Nama")
                TextBox3.Text = rd.Item("Saldo_Akhir")
            Else
                MsgBox("Data Tidak Ada!")
            End If
        End If
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub TextBox7_TextChanged(sender As Object, e As EventArgs) Handles TextBox7.TextChanged

    End Sub

    Private Sub DataGridView1_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        On Error Resume Next
        TextBox1.Text = DataGridView1.Rows(e.RowIndex).Cells(0).Value
        Call carikode()
        If rd.HasRows Then
            Call ketemu()
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        ComboBox1.Text = ""
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        Call koneksi()
        Dim EDIT As String = "Update tbdata set Nama= '" & TextBox2.Text & "',Jenis ='" & ComboBox1.Text & "',Saldo_Awal='" & TextBox3.Text & "',Jumlah='" & TextBox4.Text & "',Saldo_Akhir='" & TextBox5.Text & "' where ID='" & TextBox1.Text & "'"
        cmd = New OdbcCommand(EDIT, Conn)
        cmd.ExecuteNonQuery()
        Call tampilgrid()
    End Sub
End Class