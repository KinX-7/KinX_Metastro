﻿Imports System.Data.Odbc
Public Class Form3
    Dim Conn As OdbcConnection
    Dim cmd As OdbcCommand
    Dim Da As OdbcDataAdapter
    Dim rd As OdbcDataReader
    Dim Ds As DataSet
    Dim MyDB As String
    Sub koneksi()
        MyDB = "Driver={Mysql ODBC 3.51 Driver};Database=dbnasabah;server=localhost;uid=root"
        Conn = New OdbcConnection(MyDB)
        If Conn.State = ConnectionState.Closed Then
            Conn.Open()
        End If
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call kondisiawal()

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If MessageBox.Show("Yakin Ingin Kembali?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
            Me.Hide()
            Form2.Show()
        End If
    End Sub

    Sub kondisiawal()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox1.Enabled = False
        TextBox2.Enabled = False
        TextBox3.Enabled = False
        TextBox4.Enabled = False
        TextBox5.Enabled = False
        Button1.Text = "ADD"
        Button2.Text = "EDIT"
        Button3.Text = "HAPUS"
        Button1.Enabled = True
        Button2.Enabled = True
        Button3.Enabled = True
        Call koneksi()
        Da = New OdbcDataAdapter("select * from tbnasabah", Conn)
        Ds = New DataSet
        Ds.Clear()
        Da.Fill(Ds, "tbnasabah")
        DataGridView1.DataSource = (Ds.Tables("tbnasabah"))
    End Sub
    Sub fieldaktif()
        TextBox1.Enabled = True
        TextBox2.Enabled = True
        TextBox3.Enabled = True
        TextBox4.Enabled = True
        TextBox5.Enabled = True
        TextBox1.Focus()
    End Sub
    Sub carikode()
        cmd = New OdbcCommand("select * from tbnasabah where ID='" & TextBox1.Text & "'", Conn)
        rd = cmd.ExecuteReader
        rd.Read()

    End Sub
    Sub ketemu()
        On Error Resume Next
        TextBox2.Text = rd(1) '=Nama
        TextBox3.Text = rd(2) '=Kelas
        TextBox4.Text = rd(3) '=Username
        TextBox5.Text = rd(4) '=Password
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Button1.Text = "ADD" Then
            Button1.Text = "SIMPAN"
            Button2.Enabled = False
            Button3.Enabled = False
            Button5.Text = "BATAL"
            Call fieldaktif()
        Else
            If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Then
                MsgBox("Data Belum Lengkap..!", vbInformation, "GAGAL!")
            Else
                Call koneksi()
                Dim ADD As String = "Insert into tbnasabah values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "')"
                cmd = New OdbcCommand(ADD, Conn)
                cmd.ExecuteNonQuery()
                MsgBox("Input Data Berhasil!..", vbInformation, "SUKSES!")
                Call kondisiawal()
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If Button2.Text = "EDIT" Then
            Button2.Text = "EDIT"
            Button1.Enabled = False
            Button3.Enabled = False
            Button5.Text = "BATAL"
            Call fieldaktif()
        End If
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox("Data Belum Lengkap..!", vbInformation, "GAGAL!")
        Else
            Call koneksi()
            Dim EDIT As String = "Update tbnasabah set Nama='" & TextBox2.Text & "',Kelas='" & TextBox3.Text & "',Username='" & TextBox4.Text & "',Password='" & TextBox5.Text & "'where ID= '" & TextBox1.Text & "'"
            cmd = New OdbcCommand(EDIT, Conn)
            cmd.ExecuteNonQuery()
            MsgBox("Edit Data Berhasil!..", vbInformation, "SUKSES!")
            Call kondisiawal()
        End If
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = Chr(13) Then
            cmd = New OdbcCommand("Select * from tbnasabah where ID ='" & TextBox1.Text & "'", Conn)
            rd = cmd.ExecuteReader()
            rd.Read()
            If rd.HasRows Then
                TextBox2.Text = rd.Item("Nama")
                TextBox3.Text = rd.Item("Kelas")
                TextBox4.Text = rd.Item("Username")
                TextBox5.Text = rd.Item("Password")
            Else
                MsgBox("Data Tidak Ada..!", vbInformation, "EROR!")
            End If
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If Button3.Text = "HAPUS" Then
            Button3.Text = "HAPUS"
            Button2.Enabled = False
            Button1.Enabled = False
            Button5.Text = "BATAL"
            Call fieldaktif()
        End If
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox("Data Yang Akan Dihapus Belum Lengkap..!", vbInformation, "GAGAL!")
        Else
            If MessageBox.Show("Yakin Ingin Menghapus Data?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Call koneksi()
                Dim HAPUS As String = "delete from tbnasabah where ID= '" & TextBox1.Text & "'"
                cmd = New OdbcCommand(HAPUS, Conn)
                cmd.ExecuteNonQuery()
                MsgBox("Hapus Data Berhasil!..", vbInformation, "SUKSES!")
                Call kondisiawal()
            End If
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If Button5.Text = "Tutup" Then
            End
        Else
            Call kondisiawal()
        End If
    End Sub

    Private Sub TextBox7_TextChanged(sender As Object, e As EventArgs) Handles TextBox7.TextChanged
        Da = New OdbcDataAdapter("Select * from tbnasabah where Nama like '%" & TextBox7.Text & "%'", Conn)
        Ds = New DataSet
        Da.Fill(Ds)
        DataGridView1.DataSource = Ds.Tables(0)
        DataGridView1.ReadOnly = True
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub DataGridView1_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        On Error Resume Next
        TextBox1.Text = DataGridView1.Rows(e.RowIndex).Cells(0).Value
        Call carikode()
        If rd.HasRows Then
            Call ketemu()

        End If
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub
End Class