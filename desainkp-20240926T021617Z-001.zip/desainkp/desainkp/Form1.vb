﻿Imports System.Data.Odbc
Public Class Form1
    Dim Conn As OdbcConnection
    Dim cmd As OdbcCommand
    Dim Da As OdbcDataAdapter
    Dim rd As OdbcDataReader
    Dim Ds As DataSet
    Dim MyDB As String
    Sub koneksi()
        MyDB = "Driver={Mysql ODBC 3.51 Driver};Database=dbnasabah;server=localhost;uid=root"
        Conn = New OdbcConnection(MyDB)
        If Conn.State = ConnectionState.Closed Then
            Conn.Open()
        End If
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)
        Me.Close()

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs)
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs)
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs)


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        If TextBox1.Text = "Adm01" And TextBox2.Text = "12345" Then
            Me.Hide()
            Form2.Show()
            MsgBox("Selamat Login Anda Berhasil!")
        ElseIf TextBox1.Text IsNot "Adm01" And TextBox2.Text IsNot "12345" Then
            MsgBox("Login Anda Gagal!")
        ElseIf TextBox1.Text = "" And TextBox2.Text = "" Then
            MsgBox("Tolong Isi Username & Password Dengan Benar!")

        End If
    End Sub

    Private Sub Button3_Click_1(sender As Object, e As EventArgs)
        Me.Close()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        TextBox1.Text = ""
        TextBox2.Text = ""

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "Adm01" And TextBox2.Text = "12345" Then
            Me.Hide()
            Form2.Show()
            MsgBox("Selamat Login Anda Berhasil!", vbInformation, "SUKSES!")
        Else
            Call koneksi()
            cmd = New OdbcCommand("Select * from tbnasabah where Username= '" & TextBox1.Text & "' And Password='" & TextBox2.Text & "'", Conn)
            rd = cmd.ExecuteReader
            rd.Read()
            If rd.HasRows Then
                Me.Hide()
                form11.Show()
                MsgBox("Selamat Login Anda Berhasil!", vbInformation, "SUKSES!")
            ElseIf TextBox1.Text IsNot "Adm01" And TextBox2.Text IsNot "12345" Then
                MsgBox("Username Dan Password Anda Salah...!", vbInformation, "Gagal!")
            Else
                MsgBox("Username Atau Password Anda Salah...!", vbInformation, "Gagal!")

                If TextBox1.Text = "" And TextBox2.Text = "" Then
                    MsgBox("Mohon Isi Username Dan Password Anda...!", vbInformation, "Gagal!")
                End If
            End If
            End If
        TextBox1.Text = ""
        TextBox2.Text = ""
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
    End Sub

    Private Sub Button3_Click_2(sender As Object, e As EventArgs)
        Me.Close()

    End Sub

    Private Sub CheckBox1_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            TextBox2.UseSystemPasswordChar = False
        Else
            TextBox2.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs)

    End Sub
End Class
