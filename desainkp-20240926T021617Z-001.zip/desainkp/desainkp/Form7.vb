﻿Imports System.Data.Odbc
Public Class Form7
    Dim Conn As OdbcConnection
    Dim cmd As OdbcCommand
    Dim Da As OdbcDataAdapter
    Dim rd As OdbcDataReader
    Dim Ds As DataSet
    Dim MyDB As String
    Sub koneksi()
        MyDB = "Driver={Mysql ODBC 3.51 Driver};Database=dbnasabah;server=localhost;uid=root"
        Conn = New OdbcConnection(MyDB)
        If Conn.State = ConnectionState.Closed Then
            Conn.Open()
        End If
    End Sub
    Sub carikode()
        cmd = New OdbcCommand("select * from tbriwayat where ID_Transaksi='" & TextBox2.Text & "'", Conn)
        rd = cmd.ExecuteReader
        rd.Read()
    End Sub
    Sub ketemu()
        On Error Resume Next
        TextBox1.Text = rd(1) '=Tanggal
        TextBox2.Text = rd(2) '=ID_Transaksi
        TextBox3.Text = rd(3) '=ID
        TextBox4.Text = rd(4) '=Nama
        TextBox5.Text = rd(5) '=Jenis
        TextBox6.Text = rd(6) '=Saldo_Awal
        TextBox7.Text = rd(7) '=Jumlah
        TextBox8.Text = rd(8) '=Saldo_Akhir
    End Sub

    Private Sub Form7_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call koneksi()
        Da = New OdbcDataAdapter("select * from tbriwayat", Conn)
        Ds = New DataSet
        Ds.Clear()
        Da.Fill(Ds, "tbriwayat")
        DataGridView1.DataSource = (Ds.Tables("tbriwayat"))
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Or TextBox6.Text = "" Or TextBox7.Text = "" Then
            MsgBox("Data Yang Akan Dihapus Belum Lengkap..!", vbInformation, "GAGAL!")
        Else
            If MessageBox.Show("Yakin Ingin Menghapus Data?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Call koneksi()
                Dim HAPUS As String = "delete from tbriwayat where ID= '" & TextBox3.Text & "'"
                cmd = New OdbcCommand(HAPUS, Conn)
                cmd.ExecuteNonQuery()
                MsgBox("Hapus Data Berhasil!..", vbInformation, "SUKSES!")

            End If
        End If
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        If e.KeyChar = Chr(13) Then
            Call koneksi()
            cmd = New OdbcCommand("Select * from tbriwayat where ID_Transaksi='" & TextBox2.Text & "'", Conn)
            rd = cmd.ExecuteReader
            rd.Read()
            If rd.HasRows Then
                TextBox1.Text = rd.Item("Tanggal")
                TextBox3.Text = rd.Item("ID")
                TextBox4.Text = rd.Item("Nama")
                TextBox5.Text = rd.Item("Jenis")
                TextBox6.Text = rd.Item("Saldo_Awal")
                TextBox7.Text = rd.Item("Jumlah")
                TextBox8.Text = rd.Item("Saldo_Akhir")
            Else
                MsgBox("Data Tidak Ada!")
            End If
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox8_TextChanged(sender As Object, e As EventArgs) Handles TextBox8.TextChanged

    End Sub
End Class
